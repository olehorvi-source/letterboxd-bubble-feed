"""Letterboxd RSS aggregator package."""

